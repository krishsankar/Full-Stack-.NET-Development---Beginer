﻿
namespace GigHub.Dtos
{
    public class FollowingDto
    {
        public string FolloweeId { get; set; }
    }
}