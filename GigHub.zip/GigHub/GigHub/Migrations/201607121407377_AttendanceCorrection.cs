namespace GigHub.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AttendanceCorrection : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("dbo.Attendances");
            AddColumn("dbo.Attendances", "GigId2", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.Attendances", new[] { "GigId2", "AttendeeId" });
            DropColumn("dbo.Attendances", "GigId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Attendances", "GigId", c => c.String(nullable: false, maxLength: 128));
            DropPrimaryKey("dbo.Attendances");
            DropColumn("dbo.Attendances", "GigId2");
            AddPrimaryKey("dbo.Attendances", new[] { "GigId", "AttendeeId" });
        }
    }
}
